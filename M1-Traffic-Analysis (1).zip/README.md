# M1 Motorway Traffic Analysis using R

