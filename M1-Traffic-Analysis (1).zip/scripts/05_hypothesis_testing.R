# Script: 05_hypothesis_testing.R
# Purpose: Perform hypothesis testing on traffic speed data

