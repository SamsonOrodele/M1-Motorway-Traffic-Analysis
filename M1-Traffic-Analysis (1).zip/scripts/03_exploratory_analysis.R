# Script: 03_exploratory_analysis.R
# Purpose: Conduct EDA and visualize traffic patterns

