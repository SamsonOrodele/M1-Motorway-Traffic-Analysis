# Script: 04_sampling_analysis.R
# Purpose: Apply stratified random sampling and visualize speed variations

