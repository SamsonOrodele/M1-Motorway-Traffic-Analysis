# Script: 02_data_cleaning.R
# Purpose: Clean and preprocess the traffic data

